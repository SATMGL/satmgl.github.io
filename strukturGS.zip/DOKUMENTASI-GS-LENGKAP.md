# DOKUMENTASI CODE.GS — Jadwal Kerja Satpam
## Google Apps Script — Status: 8/20 Fungsi Selesai

**Last Updated:** Maret 2026  
**Status:** ✅ Fungsi 1-8 Selesai  
**Testing:** Semua test berjalan sukses

---

## 📋 DAFTAR ISI
1. [Konstanta & Mapping](#konstanta--mapping)
2. [Konvensi & Struktur Data](#konvensi--struktur-data)
3. [Fungsi Helper](#fungsi-helper) (✅ Selesai 5 fungsi)
4. [Fungsi Read Data](#fungsi-read-data) (✅ Selesai 1 fungsi)
5. [Fungsi Save Data](#fungsi-save-data) (✅ Selesai 2 fungsi)
6. [Fungsi Belum Dibuat](#fungsi-belum-dibuat)
7. [Pemanggilan dari HTML](#pemanggilan-dari-html)

---

## KONSTANTA & MAPPING

### MODE (Jenis Operasional)
```javascript
const MODE = {
  PEL: 'PEL',  // Pelaksanaan Kerja
  PEN: 'PEN'   // Pengiriman Absensi
};
```

**Penggunaan:**
```javascript
getSheetName(MODE.PEL, 3, 2026);  // ✅ BENAR
getSheetName('PEL', 3, 2026);     // ❌ HINDARI
```

---

### UNIT_MAPPING (Peta Unit ke Range Baris)
Memetakan nama unit ke range baris di sheet jadwal.

```javascript
const UNIT_MAPPING = {
  'AKMIL':            'A2:AI9',
  'BANDONGAN':        'A11:AI17',
  'BOROBUDUR':        'A19:AI26',
  'BOTTON':           'A28:AI34',
  'CANDIMULYO':       'A36:AI42',
  'GLAGAH':           'A44:AI50',
  'GRABAG':           'A52:AI59',
  'KAJORAN':          'A61:AI67',
  'KALIANGKRIK':      'A69:AI75',
  'KARANG GADING':    'A77:AI83',
  'KC MAGELANG':      'A85:AI100',
  'KCP SHOPPING':     'A102:AI108',
  'KRASAK':           'A110:AI116',
  'MAGELANG SELATAN': 'A118:AI124',
  'MAGELANG UTARA':   'A126:AI132',
  'MERTOYUDAN':       'A134:AI140',
  'NGABLAK':          'A142:AI148',
  'PAKIS':            'A150:AI156',
  'PAYAMAN':          'A158:AI164',
  'REJOWINANGUN':     'A166:AI173',
  'SALAMAN':          'A175:AI182',
  'SECANG':           'A184:AI191',
  'SUKARNO HATTA':    'A193:AI199',
  'TEGALREJO':        'A201:AI208',
  'TEMPURAN':         'A210:AI216',
  'WINDUSARI':        'A218:AI224'
};
```

**Total:** 26 unit

---

## KONVENSI & STRUKTUR DATA

### Struktur Sheet Jadwal (PEL03-26 / PEN03-26)

```
startRow + 0  → kosong (padding atas)
startRow + 1  → nama unit + header hari (MIN, SEN, SEL, dst)
startRow + 2  → header kolom: NO | NAMA | TANGGAL | 1 | 2 | 3 ...
startRow + 3  → personil ke-1  ← pIdx = 0
startRow + 4  → personil ke-2  ← pIdx = 1
startRow + 5  → personil ke-3  ← pIdx = 2
...dst
```

**Contoh untuk NGABLAK (startRow = 142):**
```
Baris 142 (startRow)     → [kosong, kosong, kosong, ...]
Baris 143 (startRow + 1) → [NGABLAK, kosong, HARI, MIN, SEN, ...]
Baris 144 (startRow + 2) → [NO, NAMA, TANGGAL, 1, 2, ...]
Baris 145 (startRow + 3) → [1, HARDI SANTOSO, kosong, M12, OFF, ...]
Baris 146 (startRow + 4) → [2, WORO DWI SULISTYO, kosong, TEST, SM, ...]
Baris 147 (startRow + 5) → [3, AHMAD NUR EFENDI, kosong, OFF, P, ...]
Baris 148 (startRow + 6) → [kosong, kosong, ...]
```

### Struktur Kolom

| Kolom | Letter | Isi | Catatan |
|-------|--------|-----|---------|
| 1 | A | NO | Nomor urut |
| 2 | B | NAMA | Nama personil |
| 3 | C | TANGGAL | Label (header saja) |
| 4 | D | Tanggal 1 | jIdx = 0 |
| 5 | E | Tanggal 2 | jIdx = 1 |
| ... | ... | ... | ... |
| 34 | AI | Tanggal 31 | jIdx = 30 |

### Konvensi pIdx (Index Personil)

- **pIdx = index array berbasis 0 (0-based)**
- Personil ke-1 di frontend → kirim `pIdx = 0`
- Personil ke-2 di frontend → kirim `pIdx = 1`
- Personil ke-3 di frontend → kirim `pIdx = 2`

**Rumus row di sheet:**
```
row = startRow + 3 + pIdx
```

**Contoh untuk NGABLAK (startRow = 142):**
```javascript
pIdx = 0 → row = 142 + 3 + 0 = 145 (HARDI SANTOSO)
pIdx = 1 → row = 142 + 3 + 1 = 146 (WORO DWI SULISTYO)
pIdx = 2 → row = 142 + 3 + 2 = 147 (AHMAD NUR EFENDI)
```

### Konvensi jIdx (Index Tanggal)

- **jIdx = tanggal - 1**
- Tanggal 1 → `jIdx = 0` → kolom D
- Tanggal 2 → `jIdx = 1` → kolom E
- Tanggal 15 → `jIdx = 14` → kolom R

**Rumus kolom di sheet:**
```
col = 4 + jIdx
```

**Contoh:**
```javascript
jIdx = 0  → col = 4 + 0  = 4 (D)
jIdx = 1  → col = 4 + 1  = 5 (E)
jIdx = 14 → col = 4 + 14 = 18 (R)
```

---

## FUNGSI HELPER ✅

### 1. getSheetName(mode, bulan, tahun)
Menghasilkan nama sheet dari kombinasi mode, bulan, tahun.

**Parameter:**
| Param | Tipe | Contoh | Catatan |
|-------|------|--------|---------|
| mode | String | `MODE.PEL` | Gunakan konstanta MODE |
| bulan | Number | `3` | 1-12 |
| tahun | Number/String | `2026` | 4 digit atau 2 digit |

**Return:**
```javascript
{ String } nama sheet
```

**Contoh:**
```javascript
getSheetName(MODE.PEL, 3, 2026)  // → 'PEL03-26'
getSheetName(MODE.PEN, 3, 2026)  // → 'PEN03-26'
getSheetName(MODE.PEL, 12, 2026) // → 'PEL12-26'
```

**Status:** ✅ Selesai & Ditest

---

### 2. getDaysInMonth(bulan, tahun)
Menghitung jumlah hari dalam bulan tertentu, termasuk tahun kabisat.

**Parameter:**
| Param | Tipe | Contoh | Catatan |
|-------|------|--------|---------|
| bulan | Number | `3` | 1-12 |
| tahun | Number/String | `2026` | 4 digit atau 2 digit |

**Return:**
```javascript
{ Number } jumlah hari
```

**Contoh:**
```javascript
getDaysInMonth(3, 2026)  // → 31 (Maret)
getDaysInMonth(2, 2026)  // → 28 (Februari bukan kabisat)
getDaysInMonth(2, 2024)  // → 29 (Februari kabisat)
getDaysInMonth(4, 2026)  // → 30 (April)
```

**Status:** ✅ Selesai & Ditest

---

### 3. getStartRow(range)
Mengambil nomor baris awal dari string range UNIT_MAPPING.

**Parameter:**
| Param | Tipe | Contoh | Catatan |
|-------|------|--------|---------|
| range | String | `'A142:AI148'` | Format dari UNIT_MAPPING |

**Return:**
```javascript
{ Number } nomor baris awal
```

**Contoh:**
```javascript
getStartRow('A2:AI9')      // → 2
getStartRow('A11:AI17')    // → 11
getStartRow('A142:AI148')  // → 142
```

**Status:** ✅ Selesai & Ditest

---

### 4. getUnits()
Mengembalikan daftar semua nama unit dari UNIT_MAPPING.

**Parameter:** (tidak ada)

**Return:**
```javascript
{ Array<String> } daftar nama unit
```

**Contoh:**
```javascript
getUnits()
// → ['AKMIL', 'BANDONGAN', 'BOROBUDUR', ..., 'WINDUSARI']
// Total: 26 unit
```

**Status:** ✅ Selesai & Ditest

---

### 5. getAvailableMonths(mode)
Mengembalikan daftar bulan yang tersedia berdasarkan nama sheet di spreadsheet.

**Parameter:**
| Param | Tipe | Contoh | Catatan |
|-------|------|--------|---------|
| mode | String | `MODE.PEL` | Gunakan konstanta MODE |

**Return:**
```javascript
{ Array<Object> } diurutkan dari bulan terlama ke terbaru
```

**Struktur return:**
```javascript
[
  { value: 2, tahun: '2026', sheet: 'PEL02-26' },
  { value: 3, tahun: '2026', sheet: 'PEL03-26' }
]
```

**Contoh:**
```javascript
getAvailableMonths(MODE.PEL)
// → [{ value: 2, tahun: '2026', sheet: 'PEL02-26' }, 
//     { value: 3, tahun: '2026', sheet: 'PEL03-26' }]

getAvailableMonths(MODE.PEN)
// → [{ value: 2, tahun: '2026', sheet: 'PEN02-26' }, 
//     { value: 3, tahun: '2026', sheet: 'PEN03-26' }]
```

**Status:** ✅ Selesai & Ditest

---

## FUNGSI READ DATA ✅

### 6. getJadwal(mode, bulan, tahun, unit)
Membaca data jadwal satu unit dari sheet dan mengembalikan ke frontend.

**Parameter:**
| Param | Tipe | Contoh | Catatan |
|-------|------|--------|---------|
| mode | String | `MODE.PEL` | Gunakan konstanta MODE |
| bulan | Number | `3` | 1-12 |
| tahun | Number/String | `2026` | 4 digit atau 2 digit |
| unit | String | `'NGABLAK'` | Nama unit, harus ada di UNIT_MAPPING |

**Return (Sukses):**
```javascript
{
  success: true,
  unitName: 'NGABLAK',
  headerHari: ['MIN', 'SEN', 'SEL', ...],        // 31 elemen
  headerTanggal: [1, 2, 3, ...],                  // 31 elemen
  personil: [
    {
      no: 1,
      nama: 'HARDI SANTOSO',
      jadwal: ['M12', 'OFF', 'P', ...]            // 31 elemen
    },
    // ... personil lainnya
  ],
  startRow: 142,
  lastDateCol: 33
}
```

**Return (Gagal):**
```javascript
{ success: false, message: 'Sheet PEL03-26 tidak ditemukan' }
```

**Contoh:**
```javascript
const data = getJadwal(MODE.PEL, 3, 2026, 'NGABLAK');
if (data.success) {
  console.log(`Unit: ${data.unitName}`);
  console.log(`Jumlah personil: ${data.personil.length}`);
  console.log(`Personil 1: ${data.personil[0].nama}`);
  console.log(`Jadwal personil 1 tanggal 1: ${data.personil[0].jadwal[0]}`);
}
```

**Catatan:**
- `headerHari`: Hari kalender yang dihitung dari tanggal (bukan hardcode)
- `personil`: Array diisi sesuai jumlah personil di unit (tidak selalu 3)
- `jadwal`: Array selalu 31 elemen (sesuai `lastDateCol`)

**Status:** ✅ Selesai & Ditest (3 personil di NGABLAK terbaca sempurna)

---

## FUNGSI SAVE DATA ✅

### 7. saveSingleCell(mode, bulan, tahun, unit, pIdx, jIdx, value)
Menyimpan satu nilai jadwal ke cell tertentu di sheet.

**Parameter:**
| Param | Tipe | Contoh | Catatan |
|-------|------|--------|---------|
| mode | String | `MODE.PEL` | Gunakan konstanta MODE |
| bulan | Number | `3` | 1-12 |
| tahun | Number/String | `2026` | 4 digit atau 2 digit |
| unit | String | `'NGABLAK'` | Nama unit |
| pIdx | Number | `0` | Index personil **0-based** |
| jIdx | Number | `0` | Index tanggal (= tanggal - 1) |
| value | String | `'P'` | Nilai jadwal (P, M12, OFF, SM, dst) |

**Return:**
```javascript
{ success: true, message: 'Cell berhasil disimpan' }
// atau
{ success: false, message: '...' }
```

**Contoh:**
```javascript
// Simpan 'P' ke personil ke-1 (pIdx=0), tanggal 1 (jIdx=0)
saveSingleCell(MODE.PEL, 3, 2026, 'NGABLAK', 0, 0, 'P')
// → { success: true, message: 'Cell berhasil disimpan' }

// Simpan 'OFF' ke personil ke-2 (pIdx=1), tanggal 15 (jIdx=14)
saveSingleCell(MODE.PEL, 3, 2026, 'NGABLAK', 1, 14, 'OFF')
// → { success: true, message: 'Cell berhasil disimpan' }
```

**⚠️ PENTING:**
- **pIdx = 0 untuk personil pertama** (berbeda dari kode lama yang pakai +1)
- Konvensi ini sudah ditest dan confirmed bekerja

**Status:** ✅ Selesai & Ditest (personil pertama tanggal 1 berhasil diubah ke TEST)

---

### 8. saveJadwalBatch(mode, bulan, tahun, unit, changes)
Menyimpan banyak cell sekaligus dalam satu operasi (lebih efisien dari saveSingleCell berulang).

**Parameter:**
| Param | Tipe | Contoh | Catatan |
|-------|------|--------|---------|
| mode | String | `MODE.PEL` | Gunakan konstanta MODE |
| bulan | Number | `3` | 1-12 |
| tahun | Number/String | `2026` | 4 digit atau 2 digit |
| unit | String | `'NGABLAK'` | Nama unit |
| changes | Array | Lihat struktur di bawah | Array objek `{pIdx, jIdx, value}` |

**Struktur `changes`:**
```javascript
[
  { pIdx: 0, jIdx: 0, value: 'P' },    // personil ke-1, tanggal 1
  { pIdx: 1, jIdx: 0, value: 'OFF' },  // personil ke-2, tanggal 1
  { pIdx: 2, jIdx: 14, value: 'M12' }  // personil ke-3, tanggal 15
]
```

**Return:**
```javascript
{ success: true, message: '3 cell berhasil disimpan' }
// atau
{ success: false, message: '...' }
```

**Contoh:**
```javascript
const changes = [
  { pIdx: 0, jIdx: 1, value: 'TEST1' },
  { pIdx: 1, jIdx: 1, value: 'TEST2' },
  { pIdx: 2, jIdx: 1, value: 'TEST3' }
];

const result = saveJadwalBatch(MODE.PEL, 3, 2026, 'NGABLAK', changes);
// → { success: true, message: '3 cell berhasil disimpan' }
```

**Catatan:**
- Lebih cepat dari memanggil `saveSingleCell` 3x
- Konvensi pIdx dan jIdx sama dengan `saveSingleCell`

**Status:** ✅ Selesai & Ditest (3 cell berbeda tersimpan sempurna)

---

### 9. saveJadwal(mode, bulan, tahun, unit, jadwalData)
Menyimpan seluruh jadwal satu unit sekaligus (full overwrite semua personil).

**Parameter:**
| Param | Tipe | Contoh | Catatan |
|-------|------|--------|---------|
| mode | String | `MODE.PEL` | Gunakan konstanta MODE |
| bulan | Number | `3` | 1-12 |
| tahun | Number/String | `2026` | 4 digit atau 2 digit |
| unit | String | `'NGABLAK'` | Nama unit |
| jadwalData | Array | Lihat struktur di bawah | Array objek `{jadwal: [...]}` |

**Struktur `jadwalData`:**
```javascript
[
  { jadwal: ['M12', 'OFF', 'P', ...] },   // personil ke-1, 31 elemen
  { jadwal: ['P', 'SM', 'OFF', ...] },    // personil ke-2, 31 elemen
  { jadwal: ['OFF', 'P', 'M12', ...] }    // personil ke-3, 31 elemen
]
```

**Return:**
```javascript
{ success: true, message: 'Jadwal berhasil disimpan' }
// atau
{ success: false, message: '...' }
```

**Contoh (typical use case):**
```javascript
// 1. Ambil jadwal asli
const data = await getJadwal(MODE.PEL, 3, 2026, 'NGABLAK');

// 2. Modifikasi
data.personil[0].jadwal[0] = 'P'; // ubah hari pertama personil 1

// 3. Simpan kembali
const result = saveJadwal(MODE.PEL, 3, 2026, 'NGABLAK', data.personil);
```

**⚠️ PENTING:**
- **Full overwrite** — semua data jadwal unit akan ditimpa
- Gunakan `saveSingleCell` atau `saveJadwalBatch` untuk perubahan sebagian saja
- Test sudah berjalan dan data asli berhasil dikembalikan

**Status:** ✅ Selesai & Ditest (full overwrite berhasil, restore data asli berhasil)

---

## FUNGSI BELUM DIBUAT ⬜

10. updatePersonilNama
11. swapPersonilPosition
12. getExcelData
13. getHariKerja
14. verifyPassword
15. verifyAdminPassword
16. getAllUnitPasswords
17. changeAdminPassword
18. changeUnitPassword
19. doGet
20. doPost

---

## PEMANGGILAN DARI HTML

### Fetch GET (untuk read data)
```javascript
const GS_URL = 'https://script.google.com/macros/s/XXXX/exec';

// Contoh: ambil jadwal
const res = await fetch(
  `${GS_URL}?action=getJadwal&mode=PEL&bulan=3&tahun=2026&unit=NGABLAK`
);
const data = await res.json();

if (data.success) {
  console.log(data.personil); // array personil
}
```

### Fetch POST (untuk save data)
```javascript
const GS_URL = 'https://script.google.com/macros/s/XXXX/exec';

// Contoh: simpan satu cell
const res = await fetch(GS_URL, {
  method: 'POST',
  body: JSON.stringify({
    action: 'saveSingleCell',
    mode: 'PEL',
    bulan: 3,
    tahun: 2026,
    unit: 'NGABLAK',
    pIdx: 0,
    jIdx: 0,
    value: 'P'
  })
});
const result = await res.json();
// → { success: true, message: 'Cell berhasil disimpan' }
```

---

## QUICK REFERENCE

### Test Functions di Test.gs
```javascript
// Helper
testGetSheetName()        // ✅ Sempurna
testGetDaysInMonth()      // ✅ Sempurna
testGetStartRow()         // ✅ Sempurna
testGetUnits()            // ✅ Sempurna (26 unit)
testGetAvailableMonths()  // ✅ Sempurna

// Read
testGetJadwal()           // ✅ Sempurna (3 personil)

// Save
testSaveSingleCell()      // ✅ Sempurna (cell berubah ke TEST)
testSaveJadwalBatch()     // ✅ Sempurna (3 cell berubah)
testSaveJadwal()          // ✅ Sempurna (full overwrite + restore)
```

---

## RINGKASAN STATUS

| # | Fungsi | Status | Test | Catatan |
|---|--------|--------|------|---------|
| 1 | getSheetName | ✅ | ✅ | PEL03-26 format sempurna |
| 2 | getDaysInMonth | ✅ | ✅ | Kabisat handled |
| 3 | getStartRow | ✅ | ✅ | Parse range OK |
| 4 | getUnits | ✅ | ✅ | 26 unit terbaca |
| 5 | getAvailableMonths | ✅ | ✅ | Filter & sort OK |
| 6 | getJadwal | ✅ | ✅ | 3 personil, 31 hari |
| 7 | saveSingleCell | ✅ | ✅ | pIdx 0-based confirmed |
| 8 | saveJadwalBatch | ✅ | ✅ | Multiple cells OK |
| 9 | saveJadwal | ✅ | ✅ | Full overwrite + restore |
| 19 | doGet | ✅ | ✅ | Routing getUnits, getAvailableMonths, getJadwal |
| 20 | doPost | ✅ | ✅ | Routing saveSingleCell, saveJadwalBatch, saveJadwal |
| 10-18 | Sisanya | ⬜ | ⬜ | Admin only (skip untuk sekarang) |

---

**Selanjutnya:** updatePersonilNama

*Dokumentasi ini akan diperbarui setiap fungsi baru selesai.*
