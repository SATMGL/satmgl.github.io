# CHECKLIST DEPLOYMENT & TESTING

## 📋 Pre-Deployment (Google Apps Script Setup)

### Langkah 1: Setup Project di Google Apps Script
- [ ] Buka spreadsheet jadwal Anda
- [ ] Klik **Extensions** → **Apps Script**
- [ ] Buat 2 file:
  - [ ] `Code.gs` - file utama dengan semua fungsi
  - [ ] `Test.gs` - file untuk test function

### Langkah 2: Copy & Paste Kode
- [ ] Copy kode dari `CODE.gs-LENGKAP.js` ke file `Code.gs`
- [ ] Simpan dengan Ctrl+S
- [ ] Refresh halaman Apps Script (F5)

### Langkah 3: Test di Apps Script
- [ ] Jalankan `testGetSheetName()` → ✅ harusnya berhasil
- [ ] Jalankan `testGetDaysInMonth()` → ✅ harusnya berhasil
- [ ] Jalankan `testGetStartRow()` → ✅ harusnya berhasil
- [ ] Jalankan `testGetUnits()` → ✅ harusnya berhasil (26 unit)
- [ ] Jalankan `testGetAvailableMonths()` → ✅ harusnya berhasil
- [ ] Jalankan `testGetJadwal()` → ✅ harusnya berhasil (3 personil)
- [ ] Jalankan `testSaveSingleCell()` → ✅ harusnya berhasil
- [ ] Jalankan `testSaveJadwalBatch()` → ✅ harusnya berhasil
- [ ] Jalankan `testSaveJadwal()` → ✅ harusnya berhasil

---

## 🚀 Deployment (Deploy sebagai Web App)

### Langkah 1: Deploy Project
1. Di Apps Script, klik **Deploy** (tombol di kanan atas)
2. Pilih **New deployment**
3. Pilih tipe: **Web app**
4. Di kolom "Execute as", pilih akun Google Anda
5. Di kolom "Who has access", pilih **Anyone** (untuk testing)
6. Klik **Deploy**

### Langkah 2: Copy Script ID
Setelah deploy, akan muncul dialog berisi URL:
```
https://script.google.com/macros/s/SCRIPT_ID_XXXXXXXXXXXX/usercopy
https://script.google.com/macros/s/SCRIPT_ID_XXXXXXXXXXXX/exec
```

**Copy SCRIPT_ID** yang panjang itu.

### Langkah 3: Update URL di HTML
1. Buka file `TEST-HTML-doGet-doPost.html`
2. Cari baris:
   ```javascript
   const GS_URL = 'https://script.google.com/macros/s/YOUR_SCRIPT_ID_HERE/exec';
   ```
3. Ganti `YOUR_SCRIPT_ID_HERE` dengan SCRIPT_ID Anda yang asli
4. Simpan file

---

## 🧪 Testing di Browser

### Langkah 1: Buka HTML Testing
1. Save file `TEST-HTML-doGet-doPost.html` ke local computer
2. Buka dengan browser (Chrome, Firefox, Edge, Safari)
3. Baca note di atas bahwa Anda sudah update SCRIPT_ID

### Langkah 2: Test doGet Functions
Di card pertama "doGet (GET)":
- [ ] Klik button "1. getUnits"
  - [ ] Output harus menampilkan 26 unit dalam array
- [ ] Klik button "2. getAvailableMonths (PEL)"
  - [ ] Output harus menampilkan bulan PEL yang tersedia
- [ ] Klik button "3. getAvailableMonths (PEN)"
  - [ ] Output harus menampilkan bulan PEN yang tersedia
- [ ] Klik button "4. getJadwal (NGABLAK)"
  - [ ] Output harus menampilkan jadwal unit NGABLAK dengan 3 personil

### Langkah 3: Test saveSingleCell
Di card kedua "saveSingleCell (POST)":
- [ ] Ubah "Personil" ke personil yang berbeda-beda
- [ ] Ubah "Tanggal (jIdx)" ke angka berbeda (0-30)
- [ ] Ubah "Nilai" ke nilai apa saja
- [ ] Klik "Ubah Cell"
  - [ ] Status harus "✅ Berhasil"
  - [ ] Message: "Cell berhasil disimpan"
- [ ] Klik "Verifikasi"
  - [ ] Check output apakah nilai sudah berubah

### Langkah 4: Test saveJadwalBatch
Di card ketiga "saveJadwalBatch (POST)":
- [ ] Ubah "Nilai untuk Batch" (optional)
- [ ] Klik "Ubah 3 Cell Berbeda"
  - [ ] Status harus "✅ Berhasil"
  - [ ] Message: "3 cell berhasil disimpan"
- [ ] Klik "Verifikasi"
  - [ ] Check output apakah 3 cell sudah berubah di tanggal yang sama (jIdx=1)

### Langkah 5: Test saveJadwal (Full Overwrite)
Di card keempat "saveJadwal (POST)":
- [ ] Ubah "Nilai untuk Full Overwrite" (optional)
- [ ] Klik "Full Overwrite Tanggal 3"
  - [ ] Status harus "✅ Berhasil"
  - [ ] Message: "Jadwal berhasil disimpan"
- [ ] Klik "Verifikasi"
  - [ ] Check output apakah semua personil tanggal 3 sudah berubah ke nilai baru
- [ ] Klik "Restore Data Asli" untuk restore nilai original
  - [ ] Status harus "✅ Berhasil"
  - [ ] Message: "Jadwal berhasil disimpan (Data asli berhasil dikembalikan)"

---

## 🔒 Security Notes

### Untuk Production (Jangan "Anyone")
Saat ini kita set "Anyone" untuk testing lokal. Untuk production:

1. **Authorization Flow**
   - [ ] Di Deploy settings, ubah ke "Only me" dulu
   - [ ] Implementasikan Google OAuth untuk authentication
   - [ ] Setiap request dari HTML harus include access token

2. **Password Protection** (jika diperlukan)
   - [ ] Implementasikan fungsi `verifyPassword()` (belum dibuat)
   - [ ] Setiap request harus include password validation

3. **HTTPS Only**
   - [ ] Google Apps Script deployment sudah HTTPS by default
   - [ ] Pastikan HTML client juga di HTTPS (tidak bisa mixed content)

---

## 📚 File yang Sudah Dibuat

✅ **CODE.gs-LENGKAP.js** - Main code untuk copy ke Code.gs  
✅ **doGet-doPost.js** - Contoh kode doGet & doPost (untuk referensi)  
✅ **TEST-doGet-doPost.js** - Test function untuk Apps Script  
✅ **TEST-HTML-doGet-doPost.html** - Interface testing di browser  
✅ **PANDUAN-FETCH-HTML.md** - Panduan fetch dari HTML  
✅ **DOKUMENTASI-GS-LENGKAP.md** - Dokumentasi lengkap semua fungsi  

---

## 🆘 Troubleshooting

### Error: "Script function not found: testXXX"
- [ ] Pastikan sudah ada file `Test.gs` yang berisi test function
- [ ] Klik menu `Editor` → pastikan file terlihat di left panel
- [ ] Ctrl+S untuk save

### Error: "Sheet tidak ditemukan"
- [ ] Pastikan sheet `PEL03-26` dan `PEN03-26` sudah dibuat di spreadsheet
- [ ] Pastikan nama sheet persis sesuai (case-sensitive)

### Error: "CORS" atau "403 Forbidden" di browser
- [ ] Pastikan Apps Script sudah di-deploy dengan akses "Anyone"
- [ ] Jangan mix `http://` dengan `https://`
- [ ] Coba buka link deployment di browser dulu, confirm access

### Error: "Cannot read property 'contents' of undefined"
- [ ] Di doPost, pastikan body berisi JSON yang valid
- [ ] Di HTML, pastikan `JSON.stringify()` sudah benar format

### Testing tapi data tidak berubah di spreadsheet
- [ ] Cek di Apps Script, pastikan `SpreadsheetApp.flush()` ada
- [ ] Coba refresh spreadsheet (F5 atau Ctrl+R)
- [ ] Coba run test di Apps Script dulu sebelum HTML testing

### Data TEST tidak hilang setelah restore
- [ ] Tombol restore hanya berjalan jika sudah pernah klik "getJadwal" dulu
- [ ] Jika lupa, run test di Apps Script langsung untuk restore

---

## ✅ Checklist Final

Sebelum declare "PRODUCTION READY":

- [ ] Semua test di Apps Script ✅
- [ ] Semua test di HTML browser ✅
- [ ] Data bisa dibaca dari getJadwal ✅
- [ ] Data bisa diubah dengan saveSingleCell ✅
- [ ] Data bisa diubah batch dengan saveJadwalBatch ✅
- [ ] Data bisa di-overwrite dengan saveJadwal ✅
- [ ] Data bisa di-restore dengan saveJadwal ✅
- [ ] doGet & doPost routing sempurna ✅
- [ ] HTML client sudah terintegrasi dengan GS_URL yang benar ✅

---

## 🎯 Next Steps (Fase 2)

Setelah deployment selesai, untuk phase berikutnya:

1. **Buat HTML UI untuk User**
   - Jadwal.html - interface untuk edit jadwal
   - Absensi.html - interface untuk lihat absensi

2. **Implementasikan Admin Functions** (belum dibuat)
   - updatePersonilNama
   - swapPersonilPosition
   - verifyPassword, verifyAdminPassword
   - changePassword functions

3. **Tambahan Features**
   - getExcelData - export ke Excel
   - getHariKerja - rekap hari kerja

4. **Security & Auth**
   - Implement password verification
   - Implement OAuth flow
   - Rate limiting

---

**Status:** ✅ Phase 1 Complete - Ready for Testing & Deployment

*Update checklist ini sesuai progress implementasi Anda!*
