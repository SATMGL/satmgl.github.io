# PANDUAN FETCH dari HTML ke Google Apps Script

## URL Google Apps Script (Deploy sebagai Web App)

Ganti `XXXX` dengan Script ID Anda:

```javascript
const GS_URL = 'https://script.google.com/macros/s/XXXX/exec';
```

---

## 1. FETCH GET (Read Data)

Format URL dengan query parameter:
```
${GS_URL}?action=ACTION&param1=value1&param2=value2&...
```

### 1.1 getUnits - Ambil daftar semua unit

```javascript
async function ambilSemuaUnit() {
  try {
    const res = await fetch(`${GS_URL}?action=getUnits`);
    const units = await res.json();
    
    console.log('Unit:', units);
    // → ['AKMIL', 'BANDONGAN', ..., 'WINDUSARI']
  } catch(error) {
    console.error('Error:', error);
  }
}
```

---

### 1.2 getAvailableMonths - Ambil daftar bulan yang tersedia

```javascript
async function ambilBulanTersedia(mode) {
  // mode: 'PEL' atau 'PEN'
  try {
    const res = await fetch(
      `${GS_URL}?action=getAvailableMonths&mode=${mode}`
    );
    const months = await res.json();
    
    console.log('Bulan tersedia:', months);
    // → [{ value: 2, tahun: '2026', sheet: 'PEL02-26' }, ...]
  } catch(error) {
    console.error('Error:', error);
  }
}

// Penggunaan:
// ambilBulanTersedia('PEL');
// ambilBulanTersedia('PEN');
```

---

### 1.3 getJadwal - Ambil jadwal satu unit

```javascript
async function ambilJadwal(mode, bulan, tahun, unit) {
  try {
    const res = await fetch(
      `${GS_URL}?action=getJadwal&mode=${mode}&bulan=${bulan}&tahun=${tahun}&unit=${unit}`
    );
    const data = await res.json();
    
    if (!data.success) {
      console.error('Error:', data.message);
      return;
    }

    console.log('Unit:', data.unitName);
    console.log('Jumlah personil:', data.personil.length);
    console.log('Header hari:', data.headerHari);
    console.log('Header tanggal:', data.headerTanggal);
    
    // Akses personil
    data.personil.forEach((p, idx) => {
      console.log(`${p.no}. ${p.nama}`);
      console.log(`  Jadwal: ${p.jadwal.join(', ')}`);
    });

  } catch(error) {
    console.error('Error:', error);
  }
}

// Penggunaan:
// ambilJadwal('PEL', 3, 2026, 'NGABLAK');
```

---

## 2. FETCH POST (Save/Update Data)

Format request dengan JSON body:
```javascript
fetch(GS_URL, {
  method: 'POST',
  body: JSON.stringify({
    action: 'ACTION',
    param1: value1,
    param2: value2,
    ...
  })
})
```

### 2.1 saveSingleCell - Ubah satu cell

```javascript
async function ubahSatuCell(mode, bulan, tahun, unit, pIdx, jIdx, value) {
  try {
    const res = await fetch(GS_URL, {
      method: 'POST',
      body: JSON.stringify({
        action: 'saveSingleCell',
        mode: mode,
        bulan: bulan,
        tahun: tahun,
        unit: unit,
        pIdx: pIdx,    // index personil (0-based)
        jIdx: jIdx,    // index tanggal (0-based)
        value: value   // nilai: 'P', 'M12', 'OFF', 'SM', dst
      })
    });

    const result = await res.json();
    
    if (result.success) {
      console.log('✅', result.message);
    } else {
      console.error('❌', result.message);
    }
  } catch(error) {
    console.error('Error:', error);
  }
}

// Penggunaan:
// Ubah personil ke-1 (pIdx=0), tanggal 1 (jIdx=0) menjadi 'P'
// ubahSatuCell('PEL', 3, 2026, 'NGABLAK', 0, 0, 'P');

// Ubah personil ke-2 (pIdx=1), tanggal 15 (jIdx=14) menjadi 'OFF'
// ubahSatuCell('PEL', 3, 2026, 'NGABLAK', 1, 14, 'OFF');
```

---

### 2.2 saveJadwalBatch - Ubah banyak cell sekaligus

```javascript
async function ubahBanyakCell(mode, bulan, tahun, unit, changes) {
  try {
    const res = await fetch(GS_URL, {
      method: 'POST',
      body: JSON.stringify({
        action: 'saveJadwalBatch',
        mode: mode,
        bulan: bulan,
        tahun: tahun,
        unit: unit,
        changes: changes  // array of {pIdx, jIdx, value}
      })
    });

    const result = await res.json();
    
    if (result.success) {
      console.log('✅', result.message);
    } else {
      console.error('❌', result.message);
    }
  } catch(error) {
    console.error('Error:', error);
  }
}

// Penggunaan:
const changes = [
  { pIdx: 0, jIdx: 0, value: 'P' },    // personil 1, tanggal 1
  { pIdx: 0, jIdx: 1, value: 'M12' },  // personil 1, tanggal 2
  { pIdx: 1, jIdx: 0, value: 'OFF' }   // personil 2, tanggal 1
];
ubahBanyakCell('PEL', 3, 2026, 'NGABLAK', changes);
```

---

### 2.3 saveJadwal - Ubah seluruh jadwal unit (full overwrite)

```javascript
async function simpanSeluruhJadwal(mode, bulan, tahun, unit, jadwalData) {
  try {
    const res = await fetch(GS_URL, {
      method: 'POST',
      body: JSON.stringify({
        action: 'saveJadwal',
        mode: mode,
        bulan: bulan,
        tahun: tahun,
        unit: unit,
        jadwalData: jadwalData  // array of {jadwal: [...]}
      })
    });

    const result = await res.json();
    
    if (result.success) {
      console.log('✅', result.message);
    } else {
      console.error('❌', result.message);
    }
  } catch(error) {
    console.error('Error:', error);
  }
}

// Penggunaan:
// 1. Ambil jadwal asli
const data = await fetch(`${GS_URL}?action=getJadwal&mode=PEL&bulan=3&tahun=2026&unit=NGABLAK`)
  .then(r => r.json());

// 2. Modifikasi data
data.personil[0].jadwal[0] = 'P';  // ubah personil 1, tanggal 1
data.personil[1].jadwal[5] = 'OFF'; // ubah personil 2, tanggal 6

// 3. Simpan kembali
await simpanSeluruhJadwal('PEL', 3, 2026, 'NGABLAK', data.personil);
```

---

## 3. CONTOH IMPLEMENTASI DI HTML

### Setup dasar

```html
<!DOCTYPE html>
<html>
<head>
  <title>Jadwal Kerja</title>
</head>
<body>

<script>
// URL GS (sesuaikan dengan Script ID Anda)
const GS_URL = 'https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec';

// ============================================
// HELPER FUNCTIONS
// ============================================

// GET: Helper untuk fetch GET
async function doGet(action, params = {}) {
  const query = new URLSearchParams({ action, ...params });
  const res = await fetch(`${GS_URL}?${query}`);
  return await res.json();
}

// POST: Helper untuk fetch POST
async function doPost(action, data = {}) {
  const res = await fetch(GS_URL, {
    method: 'POST',
    body: JSON.stringify({ action, ...data })
  });
  return await res.json();
}

// ============================================
// ACTUAL USAGE
// ============================================

async function contohPenggunaan() {
  // 1. Ambil semua unit
  const units = await doGet('getUnits');
  console.log('Unit:', units);

  // 2. Ambil bulan tersedia
  const months = await doGet('getAvailableMonths', { mode: 'PEL' });
  console.log('Bulan:', months);

  // 3. Ambil jadwal
  const jadwal = await doGet('getJadwal', {
    mode: 'PEL',
    bulan: 3,
    tahun: 2026,
    unit: 'NGABLAK'
  });
  console.log('Jadwal:', jadwal);

  // 4. Ubah satu cell
  const result1 = await doPost('saveSingleCell', {
    mode: 'PEL',
    bulan: 3,
    tahun: 2026,
    unit: 'NGABLAK',
    pIdx: 0,
    jIdx: 0,
    value: 'P'
  });
  console.log('Result:', result1);

  // 5. Ubah banyak cell
  const result2 = await doPost('saveJadwalBatch', {
    mode: 'PEL',
    bulan: 3,
    tahun: 2026,
    unit: 'NGABLAK',
    changes: [
      { pIdx: 0, jIdx: 0, value: 'P' },
      { pIdx: 1, jIdx: 0, value: 'OFF' }
    ]
  });
  console.log('Result:', result2);
}

// Jalankan saat page load
window.addEventListener('load', contohPenggunaan);

</script>

</body>
</html>
```

---

## 4. KONVENSI PENTING

### pIdx (Index Personil)
- **0-based array index**
- Personil ke-1 → `pIdx = 0`
- Personil ke-2 → `pIdx = 1`
- Personil ke-3 → `pIdx = 2`

### jIdx (Index Tanggal)
- **tanggal - 1**
- Tanggal 1 → `jIdx = 0`
- Tanggal 2 → `jIdx = 1`
- Tanggal 15 → `jIdx = 14`
- Tanggal 31 → `jIdx = 30`

### Mode
- **'PEL'** = Pelaksanaan Kerja
- **'PEN'** = Pengiriman Absensi

---

## 5. ERROR HANDLING

```javascript
async function ambilJadwalDenganErrorHandling(mode, bulan, tahun, unit) {
  try {
    const res = await fetch(
      `${GS_URL}?action=getJadwal&mode=${mode}&bulan=${bulan}&tahun=${tahun}&unit=${unit}`
    );
    
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }

    const data = await res.json();

    if (!data.success) {
      throw new Error(data.message || 'Gagal ambil data');
    }

    return data;

  } catch(error) {
    console.error('❌ Error:', error.message);
    // Tampilkan notifikasi ke user
    alert('Gagal ambil jadwal: ' + error.message);
    return null;
  }
}
```

---

## 6. CHEAT SHEET

| Fungsi | Metode | Contoh Call |
|--------|--------|-------------|
| getUnits | GET | `/exec?action=getUnits` |
| getAvailableMonths | GET | `/exec?action=getAvailableMonths&mode=PEL` |
| getJadwal | GET | `/exec?action=getJadwal&mode=PEL&bulan=3&tahun=2026&unit=NGABLAK` |
| saveSingleCell | POST | `{action: 'saveSingleCell', mode: 'PEL', ...}` |
| saveJadwalBatch | POST | `{action: 'saveJadwalBatch', mode: 'PEL', ...}` |
| saveJadwal | POST | `{action: 'saveJadwal', mode: 'PEL', ...}` |

---

**Catatan:** Jangan lupa deploy Google Apps Script sebagai Web App dengan akses "Anyone" untuk testing lokal.
